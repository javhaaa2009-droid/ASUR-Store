const SHEET_NAME = 'Orders';
const PRODUCTS_SHEET = 'Products';

function doGet(e) {
  if (e && e.parameter && e.parameter.action === 'products') {
    const payload = JSON.stringify(getPublicProducts_());
    const cb = String(e.parameter.callback || '');
    if (cb && /^[A-Za-z_$][0-9A-Za-z_$\.]*$/.test(cb)) return ContentService.createTextOutput(cb + '(' + payload + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
    return ContentService.createTextOutput(payload).setMimeType(ContentService.MimeType.JSON);
  }
  if (e && e.parameter && e.parameter.page === 'admin') {
    return HtmlService.createHtmlOutputFromFile('Admin')
      .setTitle('ASUR store — Admin')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
  }
  return ContentService.createTextOutput('ASUR store order service is running.');
}

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents;
    if (!raw) throw new Error('Empty request');
    const order = JSON.parse(raw);
    const required = ['name', 'phone', 'address'];
    required.forEach(k => { if (!String(order[k] || '').trim()) throw new Error('Missing ' + k); });
    if (!Array.isArray(order.items) || !order.items.length) throw new Error('No items');

    const sheet = getOrdersSheet_();
    const id = 'ASUR-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd-HHmmss') + '-' + Math.floor(100 + Math.random() * 900);
    const safe = v => String(v == null ? '' : v).replace(/[\u0000-\u001F]/g, ' ').slice(0, 2000);
    sheet.appendRow([
      id, new Date(), safe(order.name), safe(order.phone), safe(order.address),
      safe(order.note), JSON.stringify(order.items).slice(0, 45000),
      Number(order.total) || 0, 'Шинэ'
    ]);
    return ContentService.createTextOutput(JSON.stringify({ ok: true, orderId: id }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    console.error(err);
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: 'Order could not be saved' }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function setupStore() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('ASUR_SHEET_ID');
  let ss;
  if (id) {
    ss = SpreadsheetApp.openById(id);
  } else {
    ss = SpreadsheetApp.create('ASUR store — Захиалгууд');
    props.setProperty('ASUR_SHEET_ID', ss.getId());
  }
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Захиалгын дугаар', 'Огноо', 'Нэр', 'Утас', 'Хаяг', 'Нэмэлт мэдээлэл', 'Бараанууд (JSON)', 'Нийт үнэ (₮)', 'Төлөв']);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, 9).setFontWeight('bold');
  }
  let ps = ss.getSheetByName(PRODUCTS_SHEET);
  if (!ps) ps = ss.insertSheet(PRODUCTS_SHEET);
  if (ps.getLastRow() === 0) { ps.appendRow(['ID','Нэр','Үнэ','Ангилал','Размер (JSON)','Зургийн URL','Тайлбар','Шошго','Идэвхтэй']); ps.setFrozenRows(1); ps.getRange(1,1,1,9).setFontWeight('bold'); }
  return ss.getUrl();
}

function setAdminCredentialsOnce() {
  // Доорх нэвтрэх нэр, нууц үгийг өөрийнхөөрөө солиод энэ функцийг НЭГ УДАА ажиллуулна.
  const username = 'CHANGE_ADMIN_USERNAME';
  const password = 'CHANGE_THIS_TO_A_LONG_PRIVATE_PASSWORD';
  if (username === 'CHANGE_ADMIN_USERNAME' || password === 'CHANGE_THIS_TO_A_LONG_PRIVATE_PASSWORD' || password.length < 12) {
    throw new Error('Нэвтрэх нэр болон 12-аас дээш тэмдэгттэй нууц үгээ тохируулна уу.');
  }
  const props = PropertiesService.getScriptProperties();
  props.setProperty('ASUR_ADMIN_USERNAME', username);
  props.setProperty('ASUR_ADMIN_PASSWORD', password);
}

function adminLogin(username, password) {
  const props = PropertiesService.getScriptProperties();
  const savedUser = props.getProperty('ASUR_ADMIN_USERNAME');
  const saved = props.getProperty('ASUR_ADMIN_PASSWORD');
  if (!savedUser || !saved || String(username || '') !== savedUser || String(password || '') !== saved) return { ok: false };
  const token = Utilities.getUuid();
  CacheService.getScriptCache().put('asur_admin_' + token, '1', 21600);
  return { ok: true, token: token };
}

function getAdminOrders(token) {
  requireAdmin_(token);
  const sh = getOrdersSheet_();
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  return values.slice(1).reverse().map((r, index) => ({
    row: values.length - index,
    id: String(r[0]),
    date: r[1] instanceof Date ? Utilities.formatDate(r[1], Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm') : String(r[1]),
    name: String(r[2]), phone: String(r[3]), address: String(r[4]), note: String(r[5]),
    items: parseItems_(r[6]), total: Number(r[7]) || 0, status: String(r[8] || 'Шинэ')
  }));
}

function updateAdminOrderStatus(token, row, status) {
  requireAdmin_(token);
  const allowed = ['Шинэ', 'Холбогдсон', 'Хүргэлтэнд', 'Хүргэгдсэн', 'Цуцалсан'];
  if (!allowed.includes(status)) throw new Error('Invalid status');
  const sh = getOrdersSheet_();
  const r = Number(row);
  if (!Number.isInteger(r) || r < 2 || r > sh.getLastRow()) throw new Error('Invalid order row');
  sh.getRange(r, 9).setValue(status);
  return { ok: true };
}

function requireAdmin_(token) {
  if (!token || CacheService.getScriptCache().get('asur_admin_' + token) !== '1') {
    throw new Error('Admin session expired. Please log in again.');
  }
}

function getOrdersSheet_() {
  const id = PropertiesService.getScriptProperties().getProperty('ASUR_SHEET_ID');
  if (!id) throw new Error('Эхлээд setupStore() ажиллуулна уу.');
  const ss = SpreadsheetApp.openById(id);
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Захиалгын дугаар', 'Огноо', 'Нэр', 'Утас', 'Хаяг', 'Нэмэлт мэдээлэл', 'Бараанууд (JSON)', 'Нийт үнэ (₮)', 'Төлөв']);
    sh.setFrozenRows(1);
  }
  return sh;
}

function parseItems_(value) {
  try { return JSON.parse(String(value || '[]')); } catch (_) { return []; }
}


function getProductsSheet_() {
  const id = PropertiesService.getScriptProperties().getProperty('ASUR_SHEET_ID');
  if (!id) throw new Error('Эхлээд setupStore() ажиллуулна уу.');
  const ss = SpreadsheetApp.openById(id);
  let sh = ss.getSheetByName(PRODUCTS_SHEET);
  if (!sh) { sh = ss.insertSheet(PRODUCTS_SHEET); sh.appendRow(['ID','Нэр','Үнэ','Ангилал','Размер (JSON)','Зургийн URL','Тайлбар','Шошго','Идэвхтэй']); sh.setFrozenRows(1); }
  return sh;
}
function getAdminProducts(token) {
  requireAdmin_(token);
  const sh = getProductsSheet_(), v = sh.getDataRange().getValues();
  return v.length < 2 ? [] : v.slice(1).map((r,i)=>({row:i+2,id:String(r[0]),name:String(r[1]),price:Number(r[2])||0,category:String(r[3]||'top'),sizes:parseItems_(r[4]),image:String(r[5]||''),description:String(r[6]||''),tag:String(r[7]||''),active:String(r[8]).toLowerCase()!=='false'}));
}
function getPublicProducts_() {
  const sh=getProductsSheet_(), v=sh.getDataRange().getValues();
  return v.length<2?[]:v.slice(1).filter(r=>String(r[8]).toLowerCase()!=='false').map(r=>({id:String(r[0]),name:String(r[1]),price:Number(r[2])||0,category:String(r[3]||'top'),sizes:parseItems_(r[4]),image:String(r[5]||''),description:String(r[6]||''),tag:String(r[7]||'')}));
}
function saveAdminProduct(token, p) {
  requireAdmin_(token);
  if(!p || !String(p.name||'').trim()) throw new Error('Барааны нэр оруулна уу.');
  const price=Number(p.price); if(!(price>0)) throw new Error('Зөв үнэ оруулна уу.');
  let image=String(p.image||'');
  if(p.imageData){
    const m=String(p.imageData).match(/^data:(image\/(?:jpeg|png|webp));base64,([\s\S]+)$/);
    if(!m) throw new Error('JPG, PNG эсвэл WEBP зураг сонгоно уу.');
    const bytes=Utilities.base64Decode(m[2]); if(bytes.length>4*1024*1024) throw new Error('Зураг 4MB-аас бага байх ёстой.');
    const ext=m[1].split('/')[1].replace('jpeg','jpg');
    const file=DriveApp.createFile(Utilities.newBlob(bytes,m[1],'ASUR-'+Date.now()+'.'+ext));
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK,DriveApp.Permission.VIEW);
    image='https://drive.google.com/thumbnail?id='+file.getId()+'&sz=w1000';
  }
  if(!image) throw new Error('Зураг сонгоно уу.');
  const sh=getProductsSheet_(), row=Number(p.row)||0, id=String(p.id||Utilities.getUuid());
  const vals=[id,String(p.name).trim().slice(0,120),price,String(p.category||'top'),JSON.stringify(Array.isArray(p.sizes)?p.sizes:[]),image,String(p.description||'').slice(0,500),String(p.tag||'').slice(0,40),p.active===false?'FALSE':'TRUE'];
  if(row>=2 && row<=sh.getLastRow()) sh.getRange(row,1,1,9).setValues([vals]); else sh.appendRow(vals);
  return {ok:true};
}
function deleteAdminProduct(token,row){requireAdmin_(token);const sh=getProductsSheet_(),r=Number(row);if(!Number.isInteger(r)||r<2||r>sh.getLastRow())throw new Error('Бараа олдсонгүй.');sh.deleteRow(r);return {ok:true};}
